const { EventEmitter } = require('events');
const events = new EventEmitter();

module.exports = events;